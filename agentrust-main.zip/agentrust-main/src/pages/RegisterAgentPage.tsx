import { useState } from "react";

export default function RegisterAgentPage() {
  const [riskLevel, setRiskLevel] = useState<"low" | "medium" | "high">("low");
  const [execMode, setExecMode] = useState<"deterministic" | "non-deterministic">("deterministic");

  const riskOptions = [
  { key: "low" as const, label: "Low", cost: "500 TRUST", borderActive: "border-trust-blue-glow bg-trust-blue/10 shadow-[0_0_15px_rgba(91,140,255,0.3)]", textActive: "text-trust-blue" },
  { key: "medium" as const, label: "Medium", cost: "2,500 TRUST", borderActive: "border-trust-blue-glow bg-trust-blue/10 shadow-[0_0_15px_rgba(91,140,255,0.3)]", textActive: "text-trust-blue" },
  { key: "high" as const, label: "High", cost: "10,000 TRUST", borderActive: "border-trust-blue-glow bg-trust-blue/10 shadow-[0_0_15px_rgba(91,140,255,0.3)]", textActive: "text-trust-blue" }];


  return (
    <div className="max-w-[1280px] mx-auto px-6 bg-gradient-animate">
      <header className="pt-16 pb-12">
        <h1 className="text-[48px] font-bold tracking-tight leading-tight text-white">
          Register Your <span className="bg-clip-text text-transparent bg-gradient-to-r from-trust-blue to-trust-purple">AI Agent</span>
        </h1>
        <p className="max-w-3xl text-lg leading-relaxed mt-4 text-[#c2c5d0]">
          Deploy your AI agent into the AgentTrust protocol by defining its capabilities, risk level, and execution behavior so it can be validated by the decentralized network of validators.
        </p>
      </header>

      <main className="pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-10 gap-8">
          {/* Left Column */}
          <section className="lg:col-span-6 space-y-8">
            {/* Step 1 */}
            <div className="glass-effect rounded-[18px] p-6 py-[16px] px-[24px]">
              <div className="flex items-center gap-4 mb-6">
                <span className="w-8 h-8 rounded-full bg-trust-blue flex items-center justify-center font-bold text-sm text-white">1</span>
                <h2 className="text-[20px] font-semibold text-white">Agent Metadata</h2>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-400 mb-2">Metadata URI (IPFS/Arweave)</label>
                <input className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 focus:ring-2 focus:ring-trust-blue focus:border-transparent transition-all outline-none" placeholder="ipfs://Qm... or https://arweave.net/..." type="text" />
                <p className="mt-2 text-xs text-slate-500">Metadata will be fetched and validated against protocol standards.</p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="glass-effect rounded-[18px] p-6">
              <div className="flex items-center gap-4 mb-6">
                <span className="w-8 h-8 rounded-full bg-trust-blue flex items-center justify-center font-bold text-sm text-white">2</span>
                <h2 className="text-[20px] font-semibold text-white">Risk & Execution</h2>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-6">
                {riskOptions.map((opt) =>
                <button
                  key={opt.key}
                  onClick={() => setRiskLevel(opt.key)}
                  className={`h-[110px] rounded-xl border-2 text-center transition-all hover:-translate-y-0.5 ${riskLevel === opt.key ? opt.borderActive : "border-slate-700 hover:border-slate-500 bg-transparent"}`}>
                  
                    <p className={`text-xs font-bold uppercase tracking-wider mb-1 ${riskLevel === opt.key ? opt.textActive : "text-slate-400"}`}>{opt.label}</p>
                    <p className="text-sm text-slate-300 font-semibold">{opt.cost}</p>
                  </button>
                )}
              </div>
              <div className="flex flex-col gap-3 p-4 bg-slate-900/40 rounded-xl border border-slate-800">
                <div>
                  <p className="text-sm font-medium text-slate-200">Execution Mode</p>
                  <p className="text-xs text-slate-500">Forces agent to produce verifiable proofs of logic</p>
                </div>
                <div className="flex bg-black/40 p-1 rounded-[12px] border border-slate-700/50">
                  <button
                    onClick={() => setExecMode("deterministic")}
                    className={`flex-1 py-2 text-xs font-bold rounded-[8px] transition-all ${execMode === "deterministic" ? "bg-gradient-to-r from-trust-blue to-trust-purple text-white shadow-[0_0_12px_rgba(59,130,246,0.5)]" : "text-slate-500 hover:text-slate-300"}`}>
                    
                    DETERMINISTIC
                  </button>
                  <button
                    onClick={() => setExecMode("non-deterministic")}
                    className={`flex-1 py-2 text-xs font-bold rounded-[8px] transition-all ${execMode === "non-deterministic" ? "bg-gradient-to-r from-trust-blue to-trust-purple text-white shadow-[0_0_12px_rgba(59,130,246,0.5)]" : "text-slate-500 hover:text-slate-300"}`}>
                    
                    NON-DETERMINISTIC
                  </button>
                </div>
              </div>
            </div>

            {/* Step 3 */}
            <div className="glass-effect rounded-[18px] p-6">
              <div className="flex items-center gap-4 mb-6">
                <span className="w-8 h-8 rounded-full bg-trust-blue flex items-center justify-center font-bold text-sm text-white">3</span>
                <h2 className="text-[20px] font-semibold text-white">Agent Capabilities</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Capability Name</label>
                  <input className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-2 text-slate-200 focus:ring-1 focus:ring-trust-blue outline-none" placeholder="e.g. Asset Swap" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Domain</label>
                  <select className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-2 text-slate-200 focus:ring-1 focus:ring-trust-blue outline-none">
                    <option>DeFi Strategy</option>
                    <option>NLP Analysis</option>
                    <option>Cross-chain Messaging</option>
                    <option>Autonomous Governance</option>
                  </select>
                </div>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-400 mb-2">Description</label>
                <textarea className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-2 text-slate-200 focus:ring-1 focus:ring-trust-blue outline-none" placeholder="Describe the specific task behavior..." rows={2} />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-400 mb-2">Expected Reasoning</label>
                <textarea className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-2 text-slate-200 focus:ring-1 focus:ring-trust-blue outline-none" placeholder="The logic steps the agent must follow..." rows={2} />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Output Schema (JSON)</label>
                <pre className="w-full border border-slate-700 rounded-lg p-4 font-mono text-xs text-trust-blue overflow-x-auto text-[#07f271] bg-[#01020e]">{`{
  "status": "success",
  "data": {
    "action": "string",
    "params": "object"
  }
}`}</pre>
              </div>
            </div>

            {/* Registration Footer */}
            <div className="glass-effect rounded-[18px] p-8 border-t-2 border-t-trust-purple/30">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                  <p className="text-slate-400 mb-1 text-base">Required Security Deposit</p>
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-white tracking-tight text-3xl">1,000 HBAR </span>
                    <span className="px-3 py-1 bg-trust-blue/20 text-trust-blue rounded-full text-xs font-bold border border-trust-blue/30 uppercase">​​1.5 Multiplier</span>
                  </div>
                </div>
                <button className="h-[56px] px-10 rounded-[16px] bg-vibrant-gradient text-white font-bold text-lg shadow-[0_8px_25px_-5px_rgba(111,140,255,0.4)] hover:shadow-[0_12px_35px_-5px_rgba(111,140,255,0.6)] hover:brightness-110 transition-all transform hover:-translate-y-1">
                  Register Agent
                </button>
              </div>
            </div>
          </section>

          {/* Right Column */}
          <aside className="lg:col-span-4 space-y-8">
            {/* Protocol Logs */}
            <div className="glass-effect rounded-[18px] overflow-hidden flex flex-col min-h-[480px]">
              <div className="p-5 border-b border-white/5">
                <h3 className="text-[20px] font-bold text-white">Protocol Logs</h3>
                <p className="text-xs text-slate-500">Live protocol events from Hedera Mirror Node</p>
              </div>
              <div className="flex-1 bg-[rgba(8,14,28,0.95)] p-6 font-mono text-[14px] overflow-y-auto custom-scrollbar">
                <div className="space-y-4 break-words">
                  <p className="text-trust-blue"><span className="opacity-50">[08:41:12]</span> Waiting for metadata URI confirmation</p>
                  <p className="text-green-400"><span className="opacity-50">[08:41:15]</span> Risk level selected: {riskLevel.toUpperCase()}</p>
                  <p className="text-trust-blue"><span className="opacity-50">[08:41:20]</span> Stake requirement calculated</p>
                  <p className="text-slate-500 opacity-80"><span className="opacity-50">[08:41:25]</span> Polling for capability schema...</p>
                  <p className="text-slate-500 opacity-80"><span className="opacity-50">[08:41:30]</span> Preparing cryptographic handshake...</p>
                  <p className="text-white/80 cursor-blink inline-block" />
                </div>
              </div>
            </div>

            {/* Validation Flow */}
            <div className="glass-effect rounded-[18px] p-6 text-center">
              <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-6">Validation Flow</h3>
              <div className="flex justify-center items-center py-4">
                <svg className="overflow-visible" height="120" viewBox="0 0 280 120" width="280">
                  <g className="node-animate-agent">
                    <rect fill="rgba(59, 130, 246, 0.2)" height="40" rx="8" stroke="#3b82f6" strokeWidth="1.5" width="50" x="0" y="40" />
                    <text fill="white" fontFamily="Inter" fontSize="8" fontWeight="bold" textAnchor="middle" x="25" y="65">AGENT</text>
                  </g>
                  <g className="node-animate-validator">
                    <rect fill="rgba(168, 85, 247, 0.1)" height="80" rx="8" stroke="#a855f7" strokeWidth="1.5" width="60" x="110" y="20" />
                    <text fill="white" fontFamily="Inter" fontSize="8" fontWeight="bold" textAnchor="middle" x="140" y="55">VALIDATORS</text>
                    <text fill="#a855f7" fontFamily="Inter" fontSize="7" fontWeight="600" textAnchor="middle" x="140" y="75">CONSENSUS</text>
                  </g>
                  <g className="node-animate-trust">
                    <circle cx="250" cy="60" fill="rgba(34, 197, 94, 0.1)" r="25" stroke="#22c55e" strokeWidth="1.5" />
                    <text fill="white" fontFamily="Inter" fontSize="8" fontWeight="bold" textAnchor="middle" x="250" y="60">TRUST</text>
                    <text fill="#22c55e" fontFamily="Inter" fontSize="7" fontWeight="600" textAnchor="middle" x="250" y="72">SCORE</text>
                  </g>
                  <path className="flow-line" d="M50 60 H110" fill="none" stroke="#3b82f6" strokeWidth="1.5" />
                  <path className="flow-line" d="M170 60 H225" fill="none" stroke="#a855f7" strokeWidth="1.5" style={{ animationDelay: "1.5s" }} />
                </svg>
              </div>
              <p className="text-xs text-slate-500 italic mt-2">Validators continuously verify agent reasoning against proposed outputs.</p>
            </div>
          </aside>
        </div>

        {/* Danger Zone */}
        <section className="mt-12">
          <div className="bg-red-950/40 backdrop-blur-md rounded-[18px] p-6 border border-red-500/30 py-[24px]">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="max-w-md">
                <h2 className="text-lg font-bold text-red-500 mb-1">Danger Zone</h2>
                <p className="text-sm text-[#ef5d1f]">​Revoke an agent whose trust score falls below the protocol threshold due to malicious or unreliable behavior. The agent’s stake is liquidated and the caller receives a 1% bounty reward.</p>
              </div>
              <div className="flex-1 max-w-lg flex items-center gap-4">
                <input className="flex-1 bg-black/40 border border-red-900/50 rounded-lg px-4 py-3 text-sm text-slate-200 focus:ring-1 focus:ring-red-500 outline-none" placeholder="Enter Agent ID (e.g. 0x82f...)" type="text" />
                <button className="whitespace-nowrap px-6 py-3 bg-gradient-to-r from-red-600 to-red-800 text-white font-bold rounded-lg hover:brightness-110 transition-all text-sm">Revoke Agent</button>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>);

}