import { useState } from "react";

const executions = [
  { id: "#82910", hash: "0x4a7e48392f3d2e1", agent: "AlphaStrategy_v2", agentColor: "from-blue-400 to-emerald-400", type: "Deterministic", typeColor: "bg-blue-500/10 text-blue-400", outcome: "Accepted", outcomeColor: "text-green-400" },
  { id: "#82909", hash: "0x7c2299a93ef8a2", agent: "SentimentBot", agentColor: "from-purple-400 to-pink-400", type: "Non-Det", typeColor: "bg-purple-500/10 text-purple-400", outcome: "Rejected", outcomeColor: "text-red-400" },
  { id: "#82908", hash: "0x1b778262ae9c3", agent: "YieldOptimizer", agentColor: "from-yellow-400 to-orange-400", type: "Deterministic", typeColor: "bg-blue-500/10 text-blue-400", outcome: "Accepted", outcomeColor: "text-green-400" },
  { id: "#82907", hash: "0x2d919929a5b2", agent: "RiskAnalyzer", agentColor: "from-cyan-400 to-blue-400", type: "Deterministic", typeColor: "bg-blue-500/10 text-blue-400", outcome: "Accepted", outcomeColor: "text-green-400" },
  { id: "#82906", hash: "0x9f11a282e1d4", agent: "LiquidityGuard", agentColor: "from-red-400 to-orange-400", type: "Deterministic", typeColor: "bg-blue-500/10 text-blue-400", outcome: "Accepted", outcomeColor: "text-green-400" },
];

const filters = ["All", "Deterministic", "Non-Deterministic", "Accepted", "Rejected"];

export default function ExecutionsPage() {
  const [activeFilter, setActiveFilter] = useState("All");
  const [selectedExecution, setSelectedExecution] = useState(executions[0]);
  const [search, setSearch] = useState("");

  const filtered = executions.filter((e) => {
    if (search && !e.id.includes(search) && !e.agent.toLowerCase().includes(search.toLowerCase()) && !e.hash.includes(search)) return false;
    if (activeFilter === "All") return true;
    if (activeFilter === "Deterministic") return e.type === "Deterministic";
    if (activeFilter === "Non-Deterministic") return e.type === "Non-Det";
    if (activeFilter === "Accepted") return e.outcome === "Accepted";
    if (activeFilter === "Rejected") return e.outcome === "Rejected";
    return true;
  });

  return (
    <div className="relative z-10 max-w-[1280px] mx-auto px-6 py-10">
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/10 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: "2s" }} />
      </div>

      {/* Hero */}
      <section className="mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight">Execution History</h1>
        <p className="text-slate-400 text-lg max-w-2xl leading-relaxed">
          Transparent audit trail of AI agent executions, validator consensus, and protocol verification events. All operations are cryptographically secured.
        </p>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {[
          { label: "Total Executions", value: "1,284,092", badge: "+12.5%", badgeColor: "text-green-400 bg-green-400/10" },
          { label: "Successful", value: "99.2%", badge: null },
          { label: "Rejected", value: "432", badge: "Consensus Fail", badgeColor: "text-red-400 bg-red-400/10" },
          { label: "Deterministic", value: "84%", badge: "zk-Proof", badgeColor: "text-purple-400 bg-purple-400/10" },
        ].map((s) => (
          <div key={s.label} className="glass-effect p-6 rounded-twelve hover:translate-y-[-4px] transition-all duration-300 group min-h-[120px]">
            <p className="text-slate-400 text-sm mb-2 font-medium">{s.label}</p>
            <div className="flex items-end justify-between">
              <h3 className="text-3xl font-bold text-white">{s.value}</h3>
              {s.badge && <span className={`${s.badgeColor} text-xs font-mono px-2 py-1 rounded`}>{s.badge}</span>}
            </div>
          </div>
        ))}
      </section>

      {/* Search + Filters */}
      <section className="mb-8 space-y-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <span className="material-symbols-outlined text-slate-500">search</span>
            </div>
            <input
              className="w-full bg-slate-900/50 border border-white/10 rounded-twelve py-3 pl-12 pr-4 text-white placeholder-slate-500 focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none transition-all"
              placeholder="Search by Execution ID, Transaction Hash, or Agent Address..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0 no-scrollbar">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${activeFilter === f ? "bg-brand-primary text-white shadow-lg shadow-brand-primary/20" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Table + Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-[28px]" style={{ alignItems: "stretch" }}>
        <div className="glass-effect rounded-twelve flex flex-col" style={{ minHeight: 620 }}>
          <div className="p-6 pb-0 overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead className="bg-white/5 text-slate-400 text-xs uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-4 font-semibold">EX-ID / Hash</th>
                  <th className="px-6 py-4 font-semibold">Agent</th>
                  <th className="px-6 py-4 font-semibold text-center">Type</th>
                  <th className="px-6 py-4 font-semibold">Outcome</th>
                  <th className="px-6 py-4 font-semibold text-right">Action</th>
                </tr>
              </thead>
            </table>
          </div>
          <div className="flex-grow overflow-x-auto px-6">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <tbody className="divide-y divide-white/5 text-sm">
                 {filtered.map((ex) => (
                  <tr key={ex.id} className={`transition-colors cursor-pointer ${selectedExecution.id === ex.id ? "bg-white/5" : ""}`} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }} onMouseEnter={(e) => e.currentTarget.style.background = "rgba(120,140,255,0.05)"} onMouseLeave={(e) => e.currentTarget.style.background = selectedExecution.id === ex.id ? "rgba(255,255,255,0.05)" : ""} onClick={() => setSelectedExecution(ex)}>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-white font-mono font-medium">{ex.id}</span>
                        <span className="text-[10px] text-slate-500 font-mono break-all">{ex.hash}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className={`w-6 h-6 rounded-full bg-gradient-to-tr ${ex.agentColor}`} />
                        <span className="text-slate-300">{ex.agent}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`px-2 py-1 rounded ${ex.typeColor} text-[10px] font-bold uppercase tracking-wider`}>{ex.type}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`flex items-center gap-1.5 ${ex.outcomeColor}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${ex.outcome === "Accepted" ? "bg-green-400" : "bg-red-400"}`} /> {ex.outcome}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-brand-primary border border-brand-primary/20 px-3 py-1 rounded hover:bg-brand-primary hover:text-white transition-all text-xs font-medium">Inspect</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-6 py-4 border-t border-white/5 flex items-center justify-between mt-auto">
            <span className="text-xs text-slate-500">Showing 1-15 of 1.2M executions</span>
            <div className="flex gap-2">
              <button className="p-2 rounded hover:bg-white/5 text-slate-400 transition-colors">
                <span className="material-symbols-outlined text-sm">chevron_left</span>
              </button>
              <button className="p-2 rounded hover:bg-white/5 text-slate-400 transition-colors">
                <span className="material-symbols-outlined text-sm">chevron_right</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Panel */}
        <div className="flex flex-col gap-6">
          {/* Inspection */}
          <div className="glass-effect rounded-twelve p-6 bg-gradient-to-br from-brand-primary/5 to-transparent border-brand-primary/20 flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">Inspection: {selectedExecution.id}</h4>
                <p className="text-[10px] text-slate-500 font-mono mt-1 break-all">HASH: {selectedExecution.hash}669201994</p>
              </div>
              <span className={`px-2 py-1 rounded text-[10px] font-bold border ${selectedExecution.outcome === "Accepted" ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-red-500/10 text-red-400 border-red-500/20"}`}>
                {selectedExecution.outcome === "Accepted" ? "VERIFIED" : "REJECTED"}
              </span>
            </div>
            <div className="space-y-6 flex flex-col">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Metadata</span>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-black/30 p-2.5 rounded-lg border border-white/5">
                    <p className="text-[10px] text-slate-500 mb-0.5">AGENT TYPE</p>
                    <p className="text-xs text-slate-200 font-mono">DeFi Strategy</p>
                  </div>
                  <div className="bg-black/30 p-2.5 rounded-lg border border-white/5">
                    <p className="text-[10px] text-slate-500 mb-0.5">CONSENSUS</p>
                    <p className="text-xs text-slate-200 font-mono">93.3% Match</p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Full Execution Trace</span>
                <div className="bg-slate-950 rounded-lg border border-white/10 font-mono text-xs overflow-hidden flex flex-col">
                  <div className="px-3 py-2 bg-white/5 border-b border-white/5 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 uppercase">JSON View</span>
                    <span className="w-2 h-2 rounded-full bg-brand-primary" />
                  </div>
                  <div className="p-4 min-h-[300px]">
                    <pre className="leading-relaxed break-words-all"><code className="block w-full">{`{
  "agent": "${selectedExecution.agent}",
  "call": "executeRebalance",
  "params": {
    "target": "WETH/USDC",
    "threshold": 0.05,
    "slippage": 0.001
  },
  "consensus": "${selectedExecution.outcome === "Accepted" ? "MATCH" : "MISMATCH"}",
  "state": {
    "pre": "0xbc92817263542",
    "post": "0xde19920199129"
  },
  "validators": [
    "node_72",
    "node_12",
    "node_04"
  ]
}`}</code></pre>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="glass-effect rounded-twelve overflow-hidden flex flex-col flex-grow">
            <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between bg-white/5">
              <h3 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" /> Timeline
              </h3>
              <span className="text-[10px] font-mono text-slate-500">LIVE FEED</span>
            </div>
            <div className="bg-black/40 p-4 font-mono text-xs space-y-4 relative">
              <div className="scanline" />
              {[
                { time: "16:42:10", event: "ExecutionSubmitted", desc: "Agent #82911 initiated rebalancing.", color: "text-blue-400" },
                { time: "16:42:08", event: "ConsensusReached", desc: "EX-ID: #82910 validated (14/15 nodes approved state).", color: "text-green-400" },
                { time: "16:41:55", event: "VoteCast", desc: "Validator 0x921820921a1f0 approved state hash.", color: "text-yellow-400" },
                { time: "16:41:40", event: "zkProofGenerated", desc: "Zero-knowledge proof verified for execution.", color: "text-purple-400" },
              ].map((t, i) => (
                <div key={i} className="flex gap-4 group">
                  <span className="text-slate-600 flex-shrink-0">{t.time}</span>
                  <div className="flex flex-col gap-1">
                    <span className={`${t.color} font-bold`}>{t.event}</span>
                    <span className="text-slate-400">{t.desc}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
