import { useState } from "react";

export default function ValidatorsPage() {
  const [showValidatorModal, setShowValidatorModal] = useState(false);
  const [showUnregisterModal, setShowUnregisterModal] = useState(false);

  return (
    <>
      <div className="relative z-10 max-w-[1280px] mx-auto px-6 py-12 flex flex-col gap-12">
        {/* Fixed background particles */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
          <div className="absolute" style={{ top: "10%", left: "20%", width: 2, height: 2, background: "white", borderRadius: "50%", opacity: 0.12, animation: "float 10s ease-in-out infinite" }} />
          <div className="absolute" style={{ top: "40%", left: "80%", width: 2, height: 2, background: "white", borderRadius: "50%", opacity: 0.12, animation: "float 10s ease-in-out infinite 2s" }} />
          <div className="absolute" style={{ top: "70%", left: "30%", width: 2, height: 2, background: "white", borderRadius: "50%", opacity: 0.12, animation: "float 10s ease-in-out infinite 4s" }} />
        </div>

        {/* Hero */}
        <header className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="relative">
            <div className="hero-glow" />
            <h1 className="text-4xl font-bold tracking-tight text-white">
              Validator <span className="text-gradient">Network</span>
            </h1>
            <p className="mt-2 text-slate-400 max-w-xl text-lg">Decentralized consensus for secure AI agent executions.</p>
          </div>
          <button onClick={() => setShowValidatorModal(true)} className="h-[44px] px-6 btn-primary-gradient rounded-[12px] text-sm font-semibold text-white transition-all flex items-center gap-2">
            <span className="material-symbols-outlined text-[20px]">shield_person</span>
            Become Validator
          </button>
        </header>

        {/* Stats */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: "Total Validators", value: "27" },
            { label: "Active Validators", value: "24" },
            { label: "Consensus Threshold", value: "66%" },
            { label: "Minimum Votes", value: "3" },
          ].map((s) => (
            <div key={s.label} className="stat-card-refined p-[22px] rounded-[14px] hover:translate-y-[-4px] transition-all duration-300 min-h-[120px]">
              <p className="text-[13px] font-medium uppercase tracking-[0.8px] mb-3" style={{ color: "rgba(170,190,220,0.75)" }}>{s.label}</p>
              <p className="text-[32px] font-semibold" style={{ color: "#e8ecff" }}>{s.value}</p>
            </div>
          ))}
        </section>

        {/* Validator Overview */}
        <section>
          <div className="relative overflow-hidden validator-overview-refined rounded-2xl" style={{ borderRadius: 16 }}>
            <div className="absolute left-0 top-0 bottom-0 w-[4px]" style={{ background: "linear-gradient(180deg, #3b82f6, #7c3aed)" }} />
            <div className="p-8">
              <div className="flex flex-wrap justify-between items-center mb-8 gap-4 border-b border-white/5 pb-6">
                <div className="flex items-center space-x-5">
                  <div className="w-16 h-16 rounded-[14px] flex items-center justify-center font-bold text-xl text-white shrink-0" style={{ background: "radial-gradient(circle, #3b82f6, #7c3aed)", boxShadow: "0 0 20px rgba(120,140,255,0.45)" }}>V9</div>
                  <div>
                    <div className="text-xl font-bold text-white tracking-tight">Node_Alpha_721</div>
                    <div className="text-[13px] text-white/50 font-mono mt-0.5">0x4F2...88a2</div>
                  </div>
                </div>
                <span className="inline-flex items-center px-3 py-1.5 rounded-full text-[11px] font-bold" style={{ background: "rgba(34,197,94,0.15)", color: "#4ade80", border: "1px solid rgba(34,197,94,0.35)", padding: "6px 12px", borderRadius: 999 }}>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 mr-2.5 animate-pulse" />ACTIVE
                </span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:divide-x divide-white/5">
                <div className="px-2">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Stake</p>
                  <p className="text-xl font-bold text-white">100 <span className="text-xs font-normal text-slate-400 ml-0.5 uppercase tracking-tighter">HBAR</span></p>
                </div>
                <div className="px-2 md:pl-8">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Reputation</p>
                  <p className="text-xl font-bold text-trust-accent-blue">98.4%</p>
                </div>
                <div className="px-2 md:pl-8">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Registered Since</p>
                  <p className="text-lg font-semibold text-slate-300">Mar 12 2024</p>
                </div>
                <div className="px-2 md:pl-8">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Status</p>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <p className="text-sm font-medium text-slate-300">Synchronized</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Network Health */}
        <section>
          <div className="glass-card network-health-card rounded-2xl p-6 border border-white/5">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <h3 className="text-[11px] font-bold text-slate-500 uppercase tracking-[0.15em]">Network Health</h3>
              <div className="flex items-center gap-4 bg-black/20 rounded-full px-4 py-2 border border-white/5 overflow-hidden">
                <div className="flex items-center gap-2.5">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
                  </span>
                  <span className="text-xs font-bold text-emerald-400 whitespace-nowrap">Consensus Status: 99.9% Synced</span>
                </div>
                <div className="hidden md:block w-32 h-1.5 bg-white/5 rounded-full overflow-hidden shrink-0">
                  <div className="h-full w-full bg-gradient-to-r from-emerald-500 to-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.4)]" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Pending Executions + Protocol Logs */}
        <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-[28px]" style={{ alignItems: "stretch" }}>
          <section className="space-y-6 flex flex-col">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <h2 className="text-3xl font-bold text-white tracking-tight">Pending Execution Validations</h2>
              <span className="px-3 py-1 bg-white/5 rounded-lg text-[11px] font-semibold text-slate-400 border border-white/10 shrink-0">2 Actions Required</span>
            </div>
            {/* Execution 1 */}
            <div className="glass-card rounded-2xl overflow-hidden execution-card-interactive transition-all border-white/5 shadow-xl" style={{ background: "rgba(18, 24, 38, 0.95)" }}>
              <div className="p-8">
                <div className="flex flex-wrap justify-between items-start gap-4 mb-8">
                  <div className="flex items-center space-x-5">
                    <div className="p-4 bg-blue-500/10 rounded-2xl text-trust-accent-blue ring-1 ring-blue-500/20 shrink-0">
                      <span className="material-symbols-outlined text-[28px]">verified_user</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">Execution #42</h3>
                      <p className="text-sm text-slate-400 mt-1">Agent ID: <span className="text-trust-accent-purple font-medium">0x7-Sentience</span> • Strategy Execution</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2.5">
                    <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-[10px] font-bold rounded-md border border-blue-500/20 uppercase tracking-widest">Deterministic</span>
                    <span className="text-[11px] text-slate-500 font-medium">Received 2m ago</span>
                  </div>
                </div>
                <div className="bg-black/30 rounded-xl p-6 border border-white/5 mb-8 overflow-x-auto">
                  <p className="text-[10px] font-bold text-slate-500 mb-4 uppercase tracking-[0.2em]">Proposed Trace / State Change</p>
                  <div className="text-[14px] font-mono text-blue-300/80 leading-relaxed whitespace-pre">{`"swap": { "from": "HBAR", "to": "SAUCE", "amount": "5000" }`}</div>
                </div>
                <div className="flex flex-wrap justify-end items-center gap-3">
                  <button className="px-6 py-2.5 rounded-lg border border-trust-warning/30 text-trust-warning text-[10px] font-bold transition-all uppercase tracking-widest btn-ignore-hover">Ignore</button>
                  <button className="px-6 py-2.5 rounded-lg border border-trust-danger/30 text-trust-danger text-[10px] font-bold transition-all uppercase tracking-widest btn-reject-hover">Reject</button>
                  <button className="px-8 py-2.5 btn-approve-gradient rounded-lg text-[10px] font-bold text-white transition-all uppercase tracking-widest shadow-lg btn-approve-hover">Verify & Approve</button>
                </div>
              </div>
            </div>
            {/* Execution 2 */}
            <div className="glass-card rounded-2xl overflow-hidden execution-card-interactive transition-all border-white/5 shadow-xl" style={{ background: "rgba(18, 24, 38, 0.95)" }}>
              <div className="p-8">
                <div className="flex flex-wrap justify-between items-start gap-4 mb-8">
                  <div className="flex items-center space-x-5">
                    <div className="p-4 bg-purple-500/10 rounded-2xl text-trust-accent-purple ring-1 ring-purple-500/20 shrink-0">
                      <span className="material-symbols-outlined text-[32px]">warning</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">Execution #41</h3>
                      <p className="text-sm text-slate-400 mt-1">Agent ID: <span className="text-trust-accent-purple font-medium">0x9-Sentience</span> • Risk Warning</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2.5">
                    <span className="px-3 py-1 bg-purple-500/10 text-purple-400 text-[10px] font-bold rounded-md border border-purple-500/20 uppercase tracking-widest">Non-Deterministic</span>
                    <span className="text-[11px] text-slate-500 font-medium">Received 8m ago</span>
                  </div>
                </div>
                <div className="mb-8 p-6 bg-amber-500/5 rounded-xl border border-amber-500/10 overflow-x-auto">
                  <p className="text-[10px] font-bold text-slate-400/80 mb-4 uppercase tracking-[0.2em]">Heuristic Trace</p>
                  <p className="text-sm text-slate-300 leading-relaxed">The agent is proposing an execution that deviates from standard parameters. Manual verification of the logic trace is required to ensure protocol compliance.</p>
                </div>
                <div className="flex flex-wrap justify-end items-center gap-3">
                  <button className="px-6 py-2.5 rounded-lg border border-trust-warning/30 text-trust-warning text-[10px] font-bold transition-all uppercase tracking-widest btn-ignore-hover">Ignore</button>
                  <button className="px-6 py-2.5 rounded-lg border border-trust-danger/30 text-trust-danger text-[10px] font-bold transition-all uppercase tracking-widest btn-reject-hover">Reject</button>
                  <button className="px-8 py-2.5 btn-approve-gradient rounded-lg text-[10px] font-bold text-white transition-all uppercase tracking-widest shadow-lg btn-approve-hover">Verify & Approve</button>
                </div>
              </div>
            </div>
          </section>

          {/* Protocol Logs */}
          <aside className="flex flex-col lg:sticky lg:top-12">
            <div className="glass-card rounded-2xl border border-white/5 flex flex-col h-full" style={{ background: "rgba(10, 14, 23, 0.95)", minHeight: 620 }}>
              <div className="p-5 border-b border-white/5 flex items-center justify-between">
                <h3 className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Protocol Logs</h3>
                <div className="flex gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500/40" />
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500/20 border border-amber-500/40" />
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/20 border border-emerald-500/40" />
                </div>
              </div>
              <div className="p-6 font-mono text-[13px] leading-[1.6] flex-grow overflow-y-auto console-scroll space-y-3 overflow-x-auto">
                {[
                  { time: "16:02:14", text: "ExecutionSubmitted → Agent #7", color: "text-blue-400" },
                  { time: "16:02:16", text: "VoteSubmitted → Node_Alpha_721 APPROVED", color: "text-emerald-400" },
                  { time: "16:02:19", text: "VoteSubmitted → Node_Beta_421 REJECTED", color: "text-red-400" },
                  { time: "16:02:22", text: "Consensus Achieved: Execution #40 Finalized", color: "text-slate-400" },
                  { time: "16:02:45", text: "ExecutionSubmitted → Agent #9", color: "text-blue-400" },
                  { time: "16:03:01", text: "HeuristicTriggered → Risk Deviation Detected", color: "text-amber-400" },
                  { time: "16:03:12", text: "Sync complete: Block #2,941,202", color: "text-slate-400" },
                  { time: "16:03:45", text: "ExecutionSubmitted → Agent #7", color: "text-blue-400" },
                  { time: "16:04:10", text: "VoteSubmitted → Node_Gamma_901 APPROVED", color: "text-emerald-400" },
                ].map((log, i) => (
                  <div key={i} className="flex gap-3 whitespace-nowrap">
                    <span className="text-slate-600 shrink-0">[{log.time}]</span>
                    <span className={log.color}>{log.text}</span>
                  </div>
                ))}
              </div>
              <div className="mt-auto p-4 border-t border-white/5 bg-black/20">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Live Stream Active</span>
                </div>
              </div>
            </div>
          </aside>
        </div>

        {/* Validator Management */}
        <section>
          <div className="rounded-3xl p-8 border border-white/5" style={{ background: "rgba(16, 22, 35, 0.6)" }}>
            <h2 className="text-2xl font-bold text-white mb-8 tracking-tight">Validator Management</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="stake-card-refined p-8 rounded-2xl flex flex-col justify-between shadow-lg stake-card-hover min-h-[340px]">
                <div>
                  <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest mb-6">Top Up Stake</h3>
                  <div className="flex justify-between items-center mb-8 bg-black/20 p-4 rounded-xl border border-white/5">
                    <span className="text-xs text-slate-500 font-medium">Current Stake</span>
                    <span className="text-xl font-bold text-white">100 HBAR</span>
                  </div>
                  <div className="relative">
                    <input className="w-full rounded-[12px] px-5 py-3.5 text-sm text-white transition-all outline-none stake-input" placeholder="Amount to add" type="number" />
                    <span className="absolute right-5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-500 uppercase tracking-tighter">HBAR</span>
                  </div>
                </div>
                <button className="mt-8 w-full py-3 stake-btn rounded-[12px] text-[11px] font-bold text-white uppercase tracking-widest transition-all" style={{ background: "linear-gradient(90deg, #4f8cff, #7a6cff)", boxShadow: "0 0 14px rgba(120,140,255,0.35)" }}>Add Stake</button>
              </div>
              <div className="unregister-card-refined p-8 rounded-2xl flex flex-col justify-between shadow-lg unregister-card-hover min-h-[340px]">
                <div>
                  <h3 className="text-[16px] font-semibold uppercase tracking-widest mb-6" style={{ color: "#f87171" }}>Unregister Validator</h3>
                  <p className="text-[13px] text-slate-300 leading-relaxed mb-8 opacity-90">Unregistering will stop your node from participating in consensus and initiate a 7-day cooldown before stake can be withdrawn.</p>
                </div>
                <button onClick={() => setShowUnregisterModal(true)} className="w-full py-3 rounded-[12px] text-[11px] font-bold uppercase tracking-widest transition-all" style={{ background: "rgba(239,68,68,0.18)", border: "1px solid rgba(239,68,68,0.45)", color: "#ef4444" }}>Unregister Validator</button>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Validator Modal */}
      {showValidatorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="modal-overlay absolute inset-0" onClick={() => setShowValidatorModal(false)} />
          <div className="glass-card relative w-full max-w-lg rounded-[24px] overflow-hidden shadow-2xl border-white/10">
            <div className="p-8 border-b border-white/10">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white tracking-tight">Become a Validator</h2>
                <button className="p-2 hover:bg-white/5 rounded-full transition-colors" onClick={() => setShowValidatorModal(false)}>
                  <span className="material-symbols-outlined text-slate-400">close</span>
                </button>
              </div>
            </div>
            <div className="p-8 space-y-8">
              <div className="bg-blue-500/10 p-7 rounded-2xl border border-blue-500/20 shadow-inner">
                <p className="text-xs font-bold text-blue-400 uppercase tracking-widest mb-2">Staking Requirement</p>
                <div className="text-3xl font-bold text-white">100 HBAR</div>
              </div>
              <div className="space-y-5">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Responsibilities</h3>
                <ul className="space-y-4">
                  {["Maintain 99.9% node uptime and consensus synchronization.", "Verify agent execution traces against deterministic logic.", "Participate in protocol governance and parameter updates."].map((r, i) => (
                    <li key={i} className="flex items-start gap-4">
                      <span className="material-symbols-outlined text-emerald-400 text-[20px] mt-0.5">check_circle</span>
                      <span className="text-sm text-slate-300 leading-relaxed">{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <button className="w-full py-4 btn-primary-gradient rounded-2xl text-white font-bold transition-all uppercase tracking-widest text-sm shadow-xl">Confirm Stake & Register</button>
            </div>
          </div>
        </div>
      )}

      {/* Unregister Modal */}
      {showUnregisterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="modal-overlay absolute inset-0" onClick={() => setShowUnregisterModal(false)} />
          <div className="glass-card relative w-full max-w-md rounded-[24px] overflow-hidden shadow-2xl border-red-500/20">
            <div className="p-10 text-center">
              <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center text-red-500 mx-auto mb-8 ring-4 ring-red-500/5">
                <span className="material-symbols-outlined text-4xl">warning</span>
              </div>
              <h2 className="text-2xl font-bold text-white mb-3">Confirm Unregistration</h2>
              <p className="text-slate-400 text-sm leading-relaxed mb-10">Are you sure you want to unregister? This action is reversible, but requires a 7-day cooldown period before your stake can be claimed.</p>
              <div className="flex flex-col gap-4">
                <button className="w-full py-4 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl text-xs uppercase tracking-widest transition-all shadow-lg shadow-red-500/20">Yes, Unregister Node</button>
                <button onClick={() => setShowUnregisterModal(false)} className="w-full py-4 bg-white/5 hover:bg-white/10 text-slate-300 font-bold rounded-xl text-xs uppercase tracking-widest transition-all">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
