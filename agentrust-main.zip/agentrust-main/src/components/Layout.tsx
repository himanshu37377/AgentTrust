import { Link, useLocation } from "react-router-dom";

const navLinks = [
  { path: "/", label: "Home" },
  { path: "/explore", label: "Explore" },
  { path: "/register", label: "Register Agent" },
  { path: "/validators", label: "Validators" },
  { path: "/executions", label: "Execution History" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();

  return (
    <div className="relative flex flex-col min-h-screen z-10">
      {/* Background particles */}
      <div className="particle top-1/4 left-1/4 w-64 h-64 bg-trust-accent-blue rounded-full blur-[120px]" />
      <div className="particle bottom-1/4 right-1/4 w-96 h-96 bg-purple-600 rounded-full blur-[150px]" />

      <header className="sticky top-0 z-50 border-b border-white/5 bg-background-dark/80 backdrop-blur-md">
        <div className="max-w-[1280px] mx-auto px-6 flex h-20 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="size-10 btn-gradient rounded-lg flex items-center justify-center text-white">
              <span className="material-symbols-outlined text-2xl">security</span>
            </div>
            <Link to="/" className="text-xl font-bold tracking-tight text-white">AgentTrust</Link>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-medium transition-colors ${
                  location.pathname === link.path
                    ? "text-trust-accent-blue font-semibold"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-4">
            <button className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors relative">
              <span className="material-symbols-outlined text-slate-300">notifications</span>
              <span className="absolute top-2 right-2 size-2 bg-trust-accent-blue rounded-full" />
            </button>
            <button className="bg-gradient-to-r from-trust-accent-blue to-trust-accent-purple hover:brightness-110 text-white rounded-lg px-6 py-2.5 text-sm font-bold transition-all shadow-lg shadow-trust-accent-blue/20 active:scale-95">
              Connect Wallet
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="mt-16 border-t border-white/5 py-12 bg-white/[0.02]">
        <div className="max-w-[1280px] mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2 opacity-80">
            <span className="material-symbols-outlined text-trust-accent-blue">security</span>
            <span className="font-bold text-white">AgentTrust Protocol</span>
          </div>
          <div className="flex gap-8 text-sm text-slate-500 font-medium">
            <a className="hover:text-white transition-colors" href="#">Whitepaper</a>
            <a className="hover:text-white transition-colors" href="#">Security Audits</a>
            <a className="hover:text-white transition-colors" href="#">API Docs</a>
            <a className="hover:text-white transition-colors" href="#">Privacy</a>
          </div>
          <div className="flex gap-4">
            <div className="size-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 cursor-pointer transition-colors border border-white/5">
              <svg className="size-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" /></svg>
            </div>
            <div className="size-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 cursor-pointer transition-colors border border-white/5">
              <svg className="size-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.43.372.823 1.102.823 2.222 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" /></svg>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
